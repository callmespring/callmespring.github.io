/* C subroutines in R package arleGP: 
Inference for Gaussian process using approximated restricted likelihood */

// include libraries
#include<stdio.h>
#include<time.h>
#include<math.h>
#include<R.h>
#include<Rinternals.h>
#include<R_ext/Rdynload.h>
#include<gsl/gsl_vector.h>
#include<gsl/gsl_matrix.h>
#include<gsl/gsl_blas.h>
#include<gsl/gsl_linalg.h>
#include<gsl/gsl_randist.h>
#include<gsl/gsl_errno.h>
#include<gsl/gsl_multimin.h>
#include<gsl/gsl_rng.h>
#include<gsl/gsl_randist.h>

extern "C"{

// Define spdata (spatial data) to be a type of structures
struct spdata{
	// obervations
	gsl_vector *gsl_z;
	// locations
	gsl_vector *gsl_x;
	gsl_vector *gsl_y;
	// number of observations
	int n;
};

struct aspdata{
	// obervations
	gsl_vector *gsl_z;
	// locations
	gsl_vector *gsl_x;
	gsl_vector *gsl_y;
	// conditional index
	gsl_matrix *gsl_index;
	// number of observations
	int n;
	// conditioning number
	int m;
};

struct spdatalm{
	// obervations
	gsl_vector *gsl_z;
	// locations
	gsl_vector *gsl_x;
	gsl_vector *gsl_y;
	// predictors
	gsl_matrix *gsl_F;
	// number of observations
	int n;
	// dimension of F
	int p;
};

struct aspdatalm{
	// obervations
	gsl_vector *gsl_z;
	// locations
	gsl_vector *gsl_x;
	gsl_vector *gsl_y;
	// conditional index
	gsl_matrix *gsl_index;
	// predictors
	gsl_matrix *gsl_F;
	// number of observations
	int n;
	// conditioning number
	int m;
	// dimension of F
	int p;
};

// Exponential type covariance matrix
void varcov_exp_mat(double *K11, double *y, double *x, int *m, double *theta)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		// the diagonal element
		for (int i=0;i<*m;i++)
			K11[i*(*m)+i] = theta[1];
		// the off-diagonal element
		for (int i=0;i<*m;i++){
			for (int j=0;j<i;j++){
				dist = pow(y[i]-y[j], 2)+pow(x[i]-x[j], 2);
				dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
				K11[i*(*m)+j] = dist;
				K11[j*(*m)+i] = dist;
			}
		}
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

void varcov_exp_vec(double *K12, double *y, double *x, double *y0, double *x0, int *m, double *theta)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		for (int i=0;i<*m;i++)
		{
			dist = pow(y[i]-(*y0), 2)+pow(x[i]-(*x0), 2);
			dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
			K12[i] = dist;
		}
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// derivative of exponential type covariance matrix
void dvarcov_exp_mat(double *K11, double *y, double *x, int *m, double *theta, int *option)
	// option = 0: derivative with respect to theta[0], option = 1: derivative with respect to theta[1]
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		// the diagonal element
		if (*option==1){
			for (int i=0;i<*m;i++)
				K11[i*(*m)+i] = 1.0;
		}
		else{
			for (int i=0;i<*m;i++)
				K11[i*(*m)+i] = 0.0;
		}

		// the off-diagonal element
		if (*option==0){
			for (int i=0;i<*m;i++){
				for (int j=0;j<i;j++){
					dist = sqrt(pow(y[i]-y[j], 2)+pow(x[i]-x[j], 2));
					dist = -1.0*dist*exp(-theta[0]*dist/theta[1]);
					K11[i*(*m)+j] = dist;
					K11[j*(*m)+i] = dist;
				}
			}
		}
		else{
			for (int i=0;i<*m;i++){
				for (int j=0;j<i;j++){
					dist = sqrt(pow(y[i]-y[j], 2)+pow(x[i]-x[j], 2));
					dist = exp(-theta[0]*dist/theta[1])*(1.0+dist*theta[0]/theta[1]);
					K11[i*(*m)+j] = dist;
					K11[j*(*m)+i] = dist;
				}
			}
		}
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}


// derivative of exponential type covariance matrix
void dvarcov_exp_vec(double *K12, double *y, double *x, double *y0, double *x0, int *m, double *theta, int *option)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		for (int i=0;i<*m;i++)
		{
			dist = sqrt(pow(y[i]-(*y0), 2)+pow(x[i]-(*x0), 2));
			if (*option==0)
				dist = -1.0*dist*exp(-theta[0]*dist/theta[1]);
			else
				dist = exp(-theta[0]*dist/theta[1])*(1.0+theta[0]*dist/theta[1]);
			K12[i] = dist;
		}
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Rstricted likelihood for each subject
void rle_exp_f_sub(double *f, double *sub_z, double *sub_y, double *sub_x, double *z, double *y, 
					double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_temp = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp1 = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp2 = gsl_vector_alloc(*m);
		double v[1], w[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);
		gsl_vector *gsl_K12 = gsl_vector_alloc(*m);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_ptr = gsl_matrix_ptr(gsl_K11, 0, 0);
		double *K12_ptr = gsl_vector_ptr(gsl_K12, 0);

		// obtain covariance matrix
		varcov_exp_mat(K11_ptr, sub_y, sub_x, m, theta);
		varcov_exp_vec(K12_ptr, sub_y, sub_x, y, x, m, theta);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_cholesky_decomp(gsl_K11);
		if (status)
			::Rf_error( "Unable to perform cholesky decomposition because the matrix is not positive-definite");
		gsl_linalg_cholesky_solve(gsl_K11, gsl_K12, gsl_temp);
		gsl_blas_ddot(gsl_K12, gsl_temp, w);
		// v=K22-K21 K11^-1 K12
		v[0] = theta[1]-w[0];
		// w=z-K21 K11^-1 S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, gsl_temp, w);
		w[0] = z[0]-w[0];
		
		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);

		// free the allocation
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_K12);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp1);
		gsl_vector_free(gsl_temp2);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Estimating equation for each subject
void rle_exp_df_sub(double *df, double *sub_z, double *sub_y, double *sub_x, double *z, double *y, 
					double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_temp = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp1 = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp2 = gsl_vector_alloc(*m);
		double v[1], w[1], pv[2], pw[2];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);
		gsl_vector *gsl_K12 = gsl_vector_alloc(*m);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_ptr = gsl_matrix_ptr(gsl_K11, 0, 0);
		double *K12_ptr = gsl_vector_ptr(gsl_K12, 0);

		// obtain covariance matrix
		varcov_exp_mat(K11_ptr, sub_y, sub_x, m, theta);
		varcov_exp_vec(K12_ptr, sub_y, sub_x, y, x, m, theta);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_cholesky_decomp(gsl_K11);
		if (status)
			::Rf_error( "Unable to perform cholesky decomposition because the matrix is not positive-definite");
		gsl_linalg_cholesky_solve(gsl_K11, gsl_K12, gsl_temp);
		gsl_blas_ddot(gsl_K12, gsl_temp, w);
		// v=K22-K21 K11^-1 K12
		v[0] = theta[1]-w[0];
		// w=z-K21 K11^-1 S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, gsl_temp, w);
		w[0] = z[0]-w[0];
		// gsl_temp1 = gsl_K11^{-1} gsl_z
		gsl_linalg_cholesky_solve(gsl_K11, &gsl_sub_z.vector, gsl_temp1);
		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11_ptr, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_ptr, sub_y, sub_x, y, x, m, theta, &i);
			gsl_vector_set_zero(gsl_temp2);
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, gsl_temp, 0.0, gsl_temp2);
			gsl_blas_ddot(gsl_temp2, gsl_temp, &pv[i]);
			gsl_blas_ddot(gsl_temp, gsl_K12, &pw[i]);
			pv[i] = pv[i]-2.0*pw[i];
			if (i==1)
				pv[i] += 1.0;
			gsl_vector_sub(gsl_temp2, gsl_K12);
			gsl_blas_ddot(gsl_temp2, gsl_temp1, &pw[i]);
		}

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(pv[i]/v[0]+2.0*w[0]*pw[i]/v[0]-pow(w[0], 2)*pv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_K12);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp1);
		gsl_vector_free(gsl_temp2);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// estimating equation and objective function for each subject
void rle_exp_fdf_sub(double *f, double *df, double *sub_z, double *sub_y, double *sub_x, double *z, 
				double *y, double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_temp = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp1 = gsl_vector_alloc(*m);
		gsl_vector *gsl_temp2 = gsl_vector_alloc(*m);
		double v[1], w[1], pv[2], pw[2];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);
		gsl_vector *gsl_K12 = gsl_vector_alloc(*m);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_ptr = gsl_matrix_ptr(gsl_K11, 0, 0);
		double *K12_ptr = gsl_vector_ptr(gsl_K12, 0);

		// obtain covariance matrix
		varcov_exp_mat(K11_ptr, sub_y, sub_x, m, theta);
		varcov_exp_vec(K12_ptr, sub_y, sub_x, y, x, m, theta);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_cholesky_decomp(gsl_K11);
		if (status)
			::Rf_error( "Unable to perform cholesky decomposition because the matrix is not positive-definite");
		gsl_linalg_cholesky_solve(gsl_K11, gsl_K12, gsl_temp);
		gsl_blas_ddot(gsl_K12, gsl_temp, w);
		// v=K22-K21 K11^-1 K12
		v[0] = theta[1]-w[0];
		// w=z-K21 K11^-1 S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, gsl_temp, w);
		w[0] = z[0]-w[0];
		
		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);
		
		// gsl_temp1 = gsl_K11^{-1} gsl_z
		gsl_linalg_cholesky_solve(gsl_K11, &gsl_sub_z.vector, gsl_temp1);
		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11_ptr, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_ptr, sub_y, sub_x, y, x, m, theta, &i);
			gsl_vector_set_zero(gsl_temp2);
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, gsl_temp, 0.0, gsl_temp2);
			gsl_blas_ddot(gsl_temp2, gsl_temp, &pv[i]);
			gsl_blas_ddot(gsl_temp, gsl_K12, &pw[i]);
			pv[i] = pv[i]-2.0*pw[i];
			if (i==1)
				pv[i] += 1.0;
			gsl_vector_sub(gsl_temp2, gsl_K12);
			gsl_blas_ddot(gsl_temp2, gsl_temp1, &pw[i]);
		}

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(pv[i]/v[0]+2.0*w[0]*pw[i]/v[0]-pow(w[0], 2)*pv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_K12);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp1);
		gsl_vector_free(gsl_temp2);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// construct covariance matrix K11 (m+1)*(m+1) dimension
void varcov_exp_mat_cm(double *K11, double *y, double *x, int *m, double *theta)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		// the diagonal element
		for (int i=0;i<*m;i++)
			K11[i*(*m+1)+i] = theta[1];
		K11[(*m)*(*m+1)+(*m)] = 0.0;

		// the off-diagonal element
		for (int i=0;i<*m;i++){
			for (int j=0;j<i;j++){
				dist = pow(y[i]-y[j], 2)+pow(x[i]-x[j], 2);
				dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
				K11[i*(*m+1)+j] = dist;
				K11[j*(*m+1)+i] = dist;
			}
		}

		for (int i=0;i<*m;i++){
			K11[i*(*m+1)+(*m)] = 1.0;
			K11[(*m)*(*m+1)+i] = 1.0;
		}
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// 
void varcov_exp_vec_cm(double *K12, double *y, double *x, double *y0, double *x0, int *m, double *theta)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		for (int i=0;i<*m;i++)
		{
			dist = pow(y[i]-(*y0), 2)+pow(x[i]-(*x0), 2);
			dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
			K12[i] = dist;
		}
		K12[*m] = 1.0;
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

//

// construct covariance matrix K11 (m+p)*(m+p) dimension
void varcov_exp_mat_lm(double *K11, double *F, double *y, double *x, int *m, int *p, double *theta)
{
	try{
		// matrix view
		gsl_matrix_view gsl_K11 = gsl_matrix_view_array(K11, *m+*p, *m+*p);
		gsl_matrix_view gsl_K11_submat;
		gsl_matrix_view gsl_F = gsl_matrix_view_array(F, *m, *p);
		
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		// the diagonal element
		for (int i=0;i<*m;i++)
			K11[i*(*m+*p)+i] = theta[1];
		
		// the zero diagonal part
		gsl_K11_submat = gsl_matrix_submatrix(&gsl_K11.matrix, *m, *m, *p, *p);
		gsl_matrix_set_zero(&gsl_K11_submat.matrix);
		
		// the off-diagonal element
		for (int i=0;i<*m;i++){
			for (int j=0;j<i;j++){
				dist = pow(y[i]-y[j], 2)+pow(x[i]-x[j], 2);
				dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
				K11[i*(*m+*p)+j] = dist;
				K11[j*(*m+*p)+i] = dist;
			}
		}

		// the F part
		gsl_K11_submat = gsl_matrix_submatrix(&gsl_K11.matrix, 0, *m, *m, *p);
		gsl_matrix_memcpy(&gsl_K11_submat.matrix, &gsl_F.matrix);
		gsl_K11_submat = gsl_matrix_submatrix(&gsl_K11.matrix, *m, 0, *p, *m);
		gsl_matrix_transpose_memcpy(&gsl_K11_submat.matrix, &gsl_F.matrix);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

void varcov_exp_vec_lm(double *K12, double *y, double *x, double *F0, double *y0, double *x0, int *m, 
	int *p, double *theta)
{
	try{
		// when negative theta occurs
		if (theta[0]<=0)
			theta[0] = 1e-6;
		if (theta[1]<=0)
			theta[1] = 1e-6;

		double dist;
		for (int i=0;i<*m;i++)
		{
			dist = pow(y[i]-(*y0), 2)+pow(x[i]-(*x0), 2);
			dist = theta[1]*exp(-theta[0]*sqrt(dist)/theta[1]);
			K12[i] = dist;
		}
		for (int i=0;i<*p;i++)
			K12[i+(*m)] = F0[i];
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Rstricted likelihood for each subject with constant mean
void rle_exp_f_sub_cm(double *f, double *sub_z, double *sub_y, double *sub_x, double *z, double *y, 
					double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_cm = gsl_vector_alloc(*m+1);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+1);
		double v[1], w[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_cm = gsl_matrix_alloc((*m)+1, (*m)+1);
		gsl_vector *gsl_K12_cm = gsl_vector_alloc((*m)+1);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_cm = gsl_matrix_ptr(gsl_K11_cm, 0, 0);
		double *K12_cm = gsl_vector_ptr(gsl_K12_cm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_cm(K11_cm, sub_y, sub_x, m, theta);
		varcov_exp_vec_cm(K12_cm, sub_y, sub_x, y, x, m, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_cm, 0, *m);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_cm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform QR decomposition because the matrix is singular");
		gsl_linalg_QR_solve(gsl_K11_cm, gsl_tau, gsl_K12_cm, gsl_T_cm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_cm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];
		
		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);

		// free the allocation
		gsl_matrix_free(gsl_K11_cm);
		gsl_vector_free(gsl_K12_cm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_cm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Estimating equation for each subject with constant mean
void rle_exp_df_sub_cm(double *df, double *sub_z, double *sub_y, double *sub_x, double *z, double *y, 
					double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_cm = gsl_vector_alloc(*m+1);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+1);
		double v[1], w[1], dv[2], dw[2], value[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_cm = gsl_matrix_alloc((*m)+1, (*m)+1);
		gsl_vector *gsl_K12_cm = gsl_vector_alloc((*m)+1);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);
		gsl_vector *gsl_temp_cm = gsl_vector_alloc(*m+1);
		gsl_vector_view gsl_temp_m = gsl_vector_subvector(gsl_temp_cm, 0, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_cm = gsl_matrix_ptr(gsl_K11_cm, 0, 0);
		double *K12_cm = gsl_vector_ptr(gsl_K12_cm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_cm(K11_cm, sub_y, sub_x, m, theta);
		varcov_exp_vec_cm(K12_cm, sub_y, sub_x, y, x, m, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_cm, 0, *m);

		// QR decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_cm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform QR decomposition because the matrix is singular");
		gsl_linalg_QR_solve(gsl_K11_cm, gsl_tau, gsl_K12_cm, gsl_T_cm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_cm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];

		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_cm, sub_y, sub_x, y, x, m, theta, &i);
			
			// temp = dK11*T
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, &gsl_temp_m.vector);
			
			// dv[i] = T^T dK11*T
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_T.vector, &dv[i]);

			// value = T^T dK12
			gsl_blas_ddot(&gsl_T.vector, &gsl_K12.vector, value);
			dv[i] = dv[i] - 2*value[0];

			// dT
			gsl_vector_sub(&gsl_temp_m.vector, &gsl_K12.vector);
			gsl_vector_set(gsl_temp_cm, *m, 0.0);
			gsl_linalg_QR_svx(gsl_K11_cm, gsl_tau, gsl_temp_cm);
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_sub_z.vector, &dw[i]);
		}
		dv[1] = dv[1] + 1.0;

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(dv[i]/v[0]+2.0*w[0]*dw[i]/v[0]-pow(w[0], 2)*dv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11_cm);
		gsl_vector_free(gsl_K12_cm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_cm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp_cm);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// estimating equation and objective function for each subject with constant mean
void rle_exp_fdf_sub_cm(double *f, double *df, double *sub_z, double *sub_y, double *sub_x, double *z, 
				double *y, double *x, int *m, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_cm = gsl_vector_alloc(*m+1);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+1);
		double v[1], w[1], dv[2], dw[2], value[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_cm = gsl_matrix_alloc((*m)+1, (*m)+1);
		gsl_vector *gsl_K12_cm = gsl_vector_alloc((*m)+1);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);
		gsl_vector *gsl_temp_cm = gsl_vector_alloc(*m+1);
		gsl_vector_view gsl_temp_m = gsl_vector_subvector(gsl_temp_cm, 0, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_cm = gsl_matrix_ptr(gsl_K11_cm, 0, 0);
		double *K12_cm = gsl_vector_ptr(gsl_K12_cm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_cm(K11_cm, sub_y, sub_x, m, theta);
		varcov_exp_vec_cm(K12_cm, sub_y, sub_x, y, x, m, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_cm, 0, *m);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_cm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform cholesky decomposition because the matrix is not positive-definite");
		gsl_linalg_QR_solve(gsl_K11_cm, gsl_tau, gsl_K12_cm, gsl_T_cm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_cm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];

		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);

		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_cm, sub_y, sub_x, y, x, m, theta, &i);
			
			// temp = dK11*T
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, &gsl_temp_m.vector);
			
			// dv[i] = T^T dK11*T
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_T.vector, &dv[i]);

			// value = T^T dK12
			gsl_blas_ddot(&gsl_T.vector, &gsl_K12.vector, value);
			dv[i] = dv[i] - 2*value[0];

			// dT
			gsl_vector_sub(&gsl_temp_m.vector, &gsl_K12.vector);
			gsl_vector_set(gsl_temp_cm, *m, 0.0);
			gsl_linalg_QR_svx(gsl_K11_cm, gsl_tau, gsl_temp_cm);
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_sub_z.vector, &dw[i]);
		}
		dv[1] = dv[1] + 1.0;

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(dv[i]/v[0]+2.0*w[0]*dw[i]/v[0]-pow(w[0], 2)*dv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11_cm);
		gsl_vector_free(gsl_K12_cm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_cm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp_cm);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Rstricted likelihood for each subject with constant mean
void rle_exp_f_sub_lm(double *f, double *sub_F, double *sub_z, double *sub_y, double *sub_x, double *F,
					double *z, double *y, double *x, int *m, int *p, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_lm = gsl_vector_alloc(*m+*p);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+*p);
		double v[1], w[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_lm = gsl_matrix_alloc((*m)+*p, (*m)+*p);
		gsl_vector *gsl_K12_lm = gsl_vector_alloc((*m)+*p);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_lm = gsl_matrix_ptr(gsl_K11_lm, 0, 0);
		double *K12_lm = gsl_vector_ptr(gsl_K12_lm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_lm(K11_lm, sub_F, sub_y, sub_x, m, p, theta);
		varcov_exp_vec_lm(K12_lm, sub_y, sub_x, F, y, x, m, p, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_lm, 0, *m);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_lm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform QR decomposition because the matrix is singular");
		gsl_linalg_QR_solve(gsl_K11_lm, gsl_tau, gsl_K12_lm, gsl_T_lm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_lm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];
		
		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);

		// free the allocation
		gsl_matrix_free(gsl_K11_lm);
		gsl_vector_free(gsl_K12_lm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_lm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Estimating equation for each subject with constant mean
void rle_exp_df_sub_lm(double *df, double *sub_F, double *sub_z, double *sub_y, double *sub_x, 
					double *F, double *z, double *y, double *x, int *m, int *p, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_lm = gsl_vector_alloc(*m+*p);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+*p);
		double v[1], w[1], dv[2], dw[2], value[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_lm = gsl_matrix_alloc((*m)+*p, (*m)+*p);
		gsl_vector *gsl_K12_lm = gsl_vector_alloc((*m)+*p);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);
		gsl_vector *gsl_temp_lm = gsl_vector_alloc(*m+*p);
		gsl_vector_view gsl_temp_m = gsl_vector_subvector(gsl_temp_lm, 0, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_lm = gsl_matrix_ptr(gsl_K11_lm, 0, 0);
		double *K12_lm = gsl_vector_ptr(gsl_K12_lm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_lm(K11_lm, sub_F, sub_y, sub_x, m, p, theta);
		varcov_exp_vec_lm(K12_lm, sub_y, sub_x, F, y, x, m, p, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_lm, 0, *m);

		// QR decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_lm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform QR decomposition because the matrix is singular");
		gsl_linalg_QR_solve(gsl_K11_lm, gsl_tau, gsl_K12_lm, gsl_T_lm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_lm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];

		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_lm, sub_y, sub_x, y, x, m, theta, &i);
			
			// temp = dK11*T
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, &gsl_temp_m.vector);
			
			// dv[i] = T^T dK11*T
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_T.vector, &dv[i]);

			// value = T^T dK12
			gsl_blas_ddot(&gsl_T.vector, &gsl_K12.vector, value);
			dv[i] = dv[i] - 2*value[0];

			// dT
			gsl_vector_sub(&gsl_temp_m.vector, &gsl_K12.vector);
			for (int j=0;j<*p;j++)
				gsl_vector_set(gsl_temp_lm, *m+j, 0.0);
			gsl_linalg_QR_svx(gsl_K11_lm, gsl_tau, gsl_temp_lm);
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_sub_z.vector, &dw[i]);
		}
		dv[1] = dv[1] + 1.0;

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(dv[i]/v[0]+2.0*w[0]*dw[i]/v[0]-pow(w[0], 2)*dv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11_lm);
		gsl_vector_free(gsl_K12_lm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_lm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp_lm);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// estimating equation and objective function for each subject with constant mean
void rle_exp_fdf_sub_lm(double *f, double *df, double *sub_F, double *sub_z, double *sub_y, double *sub_x, 
				double *F, double *z, double *y, double *x, int *m, int *p, double *theta)
{
	try{
		// vector allocation
		gsl_vector *gsl_T_lm = gsl_vector_alloc(*m+*p);
		gsl_vector *gsl_tau = gsl_vector_alloc(*m+*p);
		double v[1], w[1], dv[2], dw[2], value[1];

		// f: estimating equations, m: number of conditioning subjects
		// construct covariance matrix K11 and K12
		gsl_matrix *gsl_K11 = gsl_matrix_alloc(*m, *m);

		gsl_matrix *gsl_K11_lm = gsl_matrix_alloc((*m)+*p, (*m)+*p);
		gsl_vector *gsl_K12_lm = gsl_vector_alloc((*m)+*p);
		gsl_vector_view gsl_sub_z = gsl_vector_view_array(sub_z, *m);
		gsl_vector *gsl_temp = gsl_vector_calloc(*m);
		gsl_vector *gsl_temp_lm = gsl_vector_alloc(*m+*p);
		gsl_vector_view gsl_temp_m = gsl_vector_subvector(gsl_temp_lm, 0, *m);

		// gsl_matrix_ptr, gsl_vector_ptr
		double *K11_lm = gsl_matrix_ptr(gsl_K11_lm, 0, 0);
		double *K12_lm = gsl_vector_ptr(gsl_K12_lm, 0);

		double *K11 = gsl_matrix_ptr(gsl_K11, 0, 0);

		// obtain covariance matrix
		varcov_exp_mat_lm(K11_lm, sub_F, sub_y, sub_x, m, p, theta);
		varcov_exp_vec_lm(K12_lm, sub_y, sub_x, F, y, x, m, p, theta);
		varcov_exp_mat(K11, sub_y, sub_x, m, theta);
		
		// K12
		gsl_vector_view gsl_K12 = gsl_vector_subvector(gsl_K12_lm, 0, *m);

		// cholesky decomposition GG'=K11, temp = solve(K11, K12)
		gsl_set_error_handler_off();
		int status = gsl_linalg_QR_decomp(gsl_K11_lm, gsl_tau);
		if (status)
			::Rf_error( "Unable to perform QR decomposition because the matrix is not positive-definite");
		gsl_linalg_QR_solve(gsl_K11_lm, gsl_tau, gsl_K12_lm, gsl_T_lm);

		// obtain gsl_T
		gsl_vector_view gsl_T = gsl_vector_subvector(gsl_T_lm, 0, *m);

		// v=K22-2*K21^T T+T^T K11 T
		gsl_blas_ddot(&gsl_K12.vector, &gsl_T.vector, w);
		v[0] = theta[1]-2*w[0];

		gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, gsl_temp);
		gsl_blas_ddot(gsl_temp, &gsl_T.vector, w);
		v[0] = v[0]+w[0];

		// w=z- T^T S_{(j-1)}
		gsl_blas_ddot(&gsl_sub_z.vector, &gsl_T.vector, w);
		w[0] = z[0]-w[0];

		// output f
		f[0] = f[0] + 0.5*(log(v[0])+pow(w[0], 2)/v[0]);

		// obtain derivative for K11 and K12
		for (int i=0;i<2;i++){
			dvarcov_exp_mat(K11, sub_y, sub_x, m, theta, &i);
			dvarcov_exp_vec(K12_lm, sub_y, sub_x, y, x, m, theta, &i);
			
			// temp = dK11*T
			gsl_blas_dgemv(CblasNoTrans, 1.0, gsl_K11, &gsl_T.vector, 0.0, &gsl_temp_m.vector);
			
			// dv[i] = T^T dK11*T
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_T.vector, &dv[i]);

			// value = T^T dK12
			gsl_blas_ddot(&gsl_T.vector, &gsl_K12.vector, value);
			dv[i] = dv[i] - 2*value[0];

			// dT
			gsl_vector_sub(&gsl_temp_m.vector, &gsl_K12.vector);
			for (int j=0;j<*p;j++)
				gsl_vector_set(gsl_temp_lm, *m+j, 0.0);
			gsl_linalg_QR_svx(gsl_K11_lm, gsl_tau, gsl_temp_lm);
			gsl_blas_ddot(&gsl_temp_m.vector, &gsl_sub_z.vector, &dw[i]);
		}
		dv[1] = dv[1] + 1.0;

		// output df
		for (int i=0;i<2;i++)
			df[i] = df[i]+0.5*(dv[i]/v[0]+2.0*w[0]*dw[i]/v[0]-pow(w[0], 2)*dv[i]/pow(v[0],2));

		// free the allocation
		gsl_matrix_free(gsl_K11_lm);
		gsl_vector_free(gsl_K12_lm);
		gsl_matrix_free(gsl_K11);
		gsl_vector_free(gsl_T_lm);
		gsl_vector_free(gsl_tau);
		gsl_vector_free(gsl_temp);
		gsl_vector_free(gsl_temp_lm);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// Estimating equation for the case where covariance possesses the exponential structure
double rle_exp_f(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// calculate the estimating equation for the first observation
//		f[1] = -0.5*(1.0/theta[1]-1.0*pow(gsl_vector_get(gsl_par_z, 0), 2)/pow(theta[1], 2));

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_f_sub(f, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], 
							&sub_y_ptr[i], &sub_x_ptr[i], &i, theta);
		}

		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void rle_exp_df (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;
		// calculate the estimating equation for the first observation
//		df[2] = -0.5/pow(theta[1], 2);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_df_sub(df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
						&sub_x_ptr[i], &i, theta);
		}
	
		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void rle_exp_fdf (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_fdf_sub(f, df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
						&sub_x_ptr[i], &i, theta);
		}

		// df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void rleGP_exp(double *x, double *y, double *z, int *n, double *theta, int *maxiter, double *tol,
	double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);

	// allocate the parameter structure
	spdata param;
	param.n = (*n);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);

	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = rle_exp_f;
	my_func.df = rle_exp_df;
	my_func.fdf = rle_exp_fdf;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
		
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);

	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
}

// Estimating equation for the case where covariance possesses the exponential structure
double arle_exp_f(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_f_sub(f, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_f_sub(f, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
		
		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void arle_exp_df (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_df_sub(df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_df_sub(df, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void arle_exp_fdf (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_fdf_sub(f, df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_fdf_sub(f, df, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// f
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void arleGP_exp(double *x, double *y, double *z, double *index, int *n, int *m, double *theta, 
	int *maxiter, double *tol, double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);
	gsl_matrix_view gsl_index_view = gsl_matrix_view_array(index, *n-*m, *m);

	// allocate the parameter structure
	aspdata param;
	param.n = (*n);
	param.m = (*m);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);
	param.gsl_index = gsl_matrix_alloc(*n-*m, *m);
	gsl_matrix_memcpy(param.gsl_index, &gsl_index_view.matrix);

	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = arle_exp_f;
	my_func.df = arle_exp_df;
	my_func.fdf = arle_exp_fdf;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);
	
	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
	gsl_matrix_free(param.gsl_index);
}

// Estimating equation for the case where covariance possesses the exponential structure
double rle_exp_f_cm(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// calculate the estimating equation for the first observation
//		f[1] = -0.5*(1.0/theta[1]-1.0*pow(gsl_vector_get(gsl_par_z, 0), 2)/pow(theta[1], 2));

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_f_sub_cm(f, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], 
							&sub_y_ptr[i], &sub_x_ptr[i], &i, theta);
		}

		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void rle_exp_df_cm (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;
		// calculate the estimating equation for the first observation
//		df[2] = -0.5/pow(theta[1], 2);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_df_sub_cm(df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
						&sub_x_ptr[i], &i, theta);
		}
	
		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void rle_exp_fdf_cm (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdata *) params)->n;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdata *) params)->gsl_y;

		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){

			// calculate the estimating equation
			rle_exp_fdf_sub_cm(f, df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
						&sub_x_ptr[i], &i, theta);
		}

		// df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void rleGP_exp_cm(double *x, double *y, double *z, int *n, double *theta, int *maxiter, double *tol,
	double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);

	// allocate the parameter structure
	spdata param;
	param.n = (*n);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);

	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = rle_exp_f_cm;
	my_func.df = rle_exp_df_cm;
	my_func.fdf = rle_exp_fdf_cm;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
		
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);

	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
}

// Estimating equation for the case where covariance possesses the exponential structure
double arle_exp_f_cm(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_f_sub_cm(f, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_f_sub_cm(f, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
		
		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void arle_exp_df_cm (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_df_sub_cm(df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_df_sub_cm(df, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void arle_exp_fdf_cm (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdata *) params)->n;
		int par_m = ((struct aspdata *) params)->m;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdata *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdata *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdata *) params)->gsl_y;

		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdata *) params)->gsl_index;

		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);

		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_m;i++){

			// calculate the estimating equation
			rle_exp_fdf_sub_cm(f, df, sub_z_ptr, sub_y_ptr, sub_x_ptr, &sub_z_ptr[i], &sub_y_ptr[i], 
				&sub_x_ptr[i], &i, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
			}

			// calculate the estimating equation
			rle_exp_fdf_sub_cm(f, df, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, &sub_z_ptr[i+par_m], 
				&sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, theta);
		}

		// f
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void arleGP_exp_cm(double *x, double *y, double *z, double *index, int *n, int *m, double *theta, 
	int *maxiter, double *tol, double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);
	gsl_matrix_view gsl_index_view = gsl_matrix_view_array(index, *n-*m, *m);

	// allocate the parameter structure
	aspdata param;
	param.n = (*n);
	param.m = (*m);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);
	param.gsl_index = gsl_matrix_alloc(*n-*m, *m);
	gsl_matrix_memcpy(param.gsl_index, &gsl_index_view.matrix);

	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = arle_exp_f_cm;
	my_func.df = arle_exp_df_cm;
	my_func.fdf = arle_exp_fdf_cm;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);
	
	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
	gsl_matrix_free(param.gsl_index);
}

// Estimating equation for the case where covariance possesses the exponential structure
double rle_exp_f_lm(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n
		int par_n = ((struct spdatalm *) params)->n;
		int par_p = ((struct spdatalm *) params)->p;
		
		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct spdatalm *) params)->gsl_F;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// calculate the estimating equation for the first observation
//		f[1] = -0.5*(1.0/theta[1]-1.0*pow(gsl_vector_get(gsl_par_z, 0), 2)/pow(theta[1], 2));

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);
		
		gsl_vector_view gsl_F0;
		
		// calculate estimating equation for the second to m observation
		for (int i=par_p;i<par_n;i++){

			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			
			// calculate the estimating equation
			rle_exp_f_sub_lm(f, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0), 
							&sub_z_ptr[i], &sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}

		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void rle_exp_df_lm (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdatalm *) params)->n;
		int par_p = ((struct spdatalm *) params)->p;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct spdatalm *) params)->gsl_F;
		
		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;
		// calculate the estimating equation for the first observation
//		df[2] = -0.5/pow(theta[1], 2);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);
		
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);
		
		gsl_vector_view gsl_F0;
//		double *F0 = gsl_vector_ptr(&gsl_F0.vector, 0);
		
		// calculate estimating equation for the second to m observation
		for (int i=par_p;i<par_n;i++){
			
			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			// calculate the estimating equation
			rle_exp_df_sub_lm(df, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0),
							&sub_z_ptr[i], &sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}
	
		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void rle_exp_fdf_lm (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct spdatalm *) params)->n;
		int par_p = ((struct spdatalm *) params)->p;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct spdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct spdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct spdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct spdatalm *) params)->gsl_F;
		
		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);		
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);
		
		gsl_vector_view gsl_F0;
//		double *F0 = gsl_vector_ptr(&gsl_F0.vector, 0);
		
		// calculate estimating equation for the second to m observation
		for (int i=1;i<par_n;i++){
				
			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			// calculate the estimating equation
			rle_exp_fdf_sub_lm(f, df, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0),
						&sub_z_ptr[i], &sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}

		// df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void rleGP_exp_lm(double *F, double *x, double *y, double *z, int *n, int *p, double *theta, 
	int *maxiter, double *tol, double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_matrix_view gsl_F_view = gsl_matrix_view_array(F, *n, *p);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);

	// allocate the parameter structure
	spdatalm param;
	param.n = (*n);
	param.p = (*p);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);
	param.gsl_F = gsl_matrix_alloc(*n, *p);
	gsl_matrix_memcpy(param.gsl_F, &gsl_F_view.matrix);
	
	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = rle_exp_f_lm;
	my_func.df = rle_exp_df_lm;
	my_func.fdf = rle_exp_fdf_lm;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
		
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);

	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
	gsl_matrix_free(param.gsl_F);
}

// Estimating equation for the case where covariance possesses the exponential structure
double arle_exp_f_lm(const gsl_vector *gsl_theta, void *params)
{
	try{
		// n and m
		int par_n = ((struct aspdatalm *) params)->n;
		int par_m = ((struct aspdatalm *) params)->m;
		int par_p = ((struct aspdatalm *) params)->p;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct aspdatalm *) params)->gsl_F;

		// allocate matrix index
		gsl_matrix *gsl_par_index = ((struct aspdatalm *) params)->gsl_index;

		// theta, f
		double theta[2], f[1];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		f[0] = 0.0;

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);
		
		gsl_vector_view gsl_F0;
//		double *F0 = gsl_vector_ptr(&gsl_F0.vector, 0);
		// calculate estimating equation for the second to m observation
		for (int i=par_p;i<par_m;i++){
			
			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			// calculate the estimating equation
			rle_exp_f_sub_lm(f, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0), 
				&sub_z_ptr[i], &sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);
		gsl_matrix *gsl_con_sub_F=gsl_matrix_alloc(par_m, par_p);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);
		double *con_sub_F_ptr = gsl_matrix_ptr(gsl_con_sub_F, 0, 0);
		
		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
				for (int k=0;k<par_p;k++){
					con_sub_F_ptr[j*par_p+k] = gsl_matrix_get(gsl_par_F, 
						(int) gsl_matrix_get(gsl_par_index, i, j), k);
				}
			}
			
			gsl_F0 = gsl_matrix_row(gsl_par_F, i+par_m);
			// calculate the estimating equation
			rle_exp_f_sub_lm(f, con_sub_F_ptr, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0),
				&sub_z_ptr[i+par_m], &sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, &par_p, theta);
		}

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
		gsl_matrix_free(gsl_con_sub_F);
		
		return (f[0]);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative of the estimating equation
void arle_exp_df_lm (const gsl_vector *gsl_theta, void *params, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdatalm *) params)->n;
		int par_m = ((struct aspdatalm *) params)->m;
		int par_p = ((struct aspdatalm *) params)->p;
		
		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct aspdatalm *) params)->gsl_F;
		
		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdatalm *) params)->gsl_index;

		// theta, f
		double theta[2], df[2];
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);
		df[0] = 0.0;
		df[1] = 0.0;
		
		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);
		
		gsl_vector_view gsl_F0;
//		double *F0 = gsl_vector_ptr(&gsl_F0.vector, 0);
		
		// calculate estimating equation for the second to m observation
		for (int i=par_p;i<par_m;i++){
			
			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			// calculate the estimating equation
			rle_exp_df_sub_lm(df, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0), &sub_z_ptr[i], 
				&sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);
		gsl_matrix *gsl_con_sub_F=gsl_matrix_alloc(par_m, par_p);

		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);
		double *con_sub_F_ptr = gsl_matrix_ptr(gsl_con_sub_F, 0, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
				for (int k=0;k<par_p;k++){
					con_sub_F_ptr[j*par_p+k] = gsl_matrix_get(gsl_par_F, 
						(int) gsl_matrix_get(gsl_par_index, i, j), k);
				}
			}

			gsl_F0 = gsl_matrix_row(gsl_par_F, i+par_m);
			
			// calculate the estimating equation
			rle_exp_df_sub_lm(df, con_sub_F_ptr, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0),
				&sub_z_ptr[i+par_m], &sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, &par_p, theta);
		}

		// df to gsl_df
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
		gsl_matrix_free(gsl_con_sub_F);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

// calculate the derivative as well as the estimating equation
void arle_exp_fdf_lm (const gsl_vector *gsl_theta, void *params, double *f, gsl_vector *gsl_df){
	try{
		// n and m
		int par_n = ((struct aspdatalm *) params)->n;
		int par_m = ((struct aspdatalm *) params)->m;
		int par_p = ((struct aspdatalm *) params)->p;

		// allocate vectors z, x and y
		gsl_vector *gsl_par_z = ((struct aspdatalm *) params)->gsl_z;
		gsl_vector *gsl_par_x = ((struct aspdatalm *) params)->gsl_x;
		gsl_vector *gsl_par_y = ((struct aspdatalm *) params)->gsl_y;
		gsl_matrix *gsl_par_F = ((struct aspdatalm *) params)->gsl_F;
		
		// allocate matrix index and dist
		gsl_matrix *gsl_par_index = ((struct aspdatalm *) params)->gsl_index;

		// theta, f
		double theta[2], df[2]={0.0, 0.0};
		theta[0] = gsl_vector_get(gsl_theta, 0);
		theta[1] = gsl_vector_get(gsl_theta, 1);

		// define conditional set
		double *sub_z_ptr = gsl_vector_ptr(gsl_par_z, 0);
		double *sub_x_ptr = gsl_vector_ptr(gsl_par_x, 0);
		double *sub_y_ptr = gsl_vector_ptr(gsl_par_y, 0);
		double *sub_F_ptr = gsl_matrix_ptr(gsl_par_F, 0, 0);

		gsl_vector_view gsl_F0;
//		double *F0 = gsl_vector_ptr(&gsl_F0.vector, 0);
		// calculate estimating equation for the second to m observation
		for (int i=par_p;i<par_m;i++){

			gsl_F0 = gsl_matrix_row(gsl_par_F, i);
			// calculate the estimating equation
			rle_exp_fdf_sub_lm(f, df, sub_F_ptr, sub_z_ptr, sub_y_ptr, sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0), 
				&sub_z_ptr[i], &sub_y_ptr[i], &sub_x_ptr[i], &i, &par_p, theta);
		}

		gsl_vector *gsl_con_sub_z=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_x=gsl_vector_alloc(par_m);
		gsl_vector *gsl_con_sub_y=gsl_vector_alloc(par_m);
		gsl_matrix *gsl_con_sub_F=gsl_matrix_alloc(par_m, par_p);
		
		double *con_sub_z_ptr = gsl_vector_ptr(gsl_con_sub_z, 0);
		double *con_sub_x_ptr = gsl_vector_ptr(gsl_con_sub_x, 0);
		double *con_sub_y_ptr = gsl_vector_ptr(gsl_con_sub_y, 0);
		double *con_sub_F_ptr = gsl_matrix_ptr(gsl_con_sub_F, 0, 0);

		for (int i=0;i<par_n-par_m;i++){
			// obtain conditional set
			for (int j=0;j<par_m;j++){
				con_sub_z_ptr[j] = gsl_vector_get(gsl_par_z, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_x_ptr[j] = gsl_vector_get(gsl_par_x, (int) gsl_matrix_get(gsl_par_index, i, j));
				con_sub_y_ptr[j] = gsl_vector_get(gsl_par_y, (int) gsl_matrix_get(gsl_par_index, i, j));
				for (int k=0;k<par_p;k++){
					con_sub_F_ptr[j*par_p+k] = gsl_matrix_get(gsl_par_F, 
						(int) gsl_matrix_get(gsl_par_index, i, j), k);
				}
			}

			gsl_F0 = gsl_matrix_row(gsl_par_F, i+par_m);
			// calculate the estimating equation
			rle_exp_fdf_sub_lm(f, df, con_sub_F_ptr, con_sub_z_ptr, con_sub_y_ptr, con_sub_x_ptr, gsl_vector_ptr(&gsl_F0.vector, 0), 
				&sub_z_ptr[i+par_m], &sub_y_ptr[i+par_m], &sub_x_ptr[i+par_m], &par_m, &par_p, theta);
		}

		// f
		gsl_vector_set(gsl_df, 0, df[0]);
		gsl_vector_set(gsl_df, 1, df[1]);

		// free allocation
		gsl_vector_free(gsl_con_sub_z);
		gsl_vector_free(gsl_con_sub_x);
		gsl_vector_free(gsl_con_sub_y);
		gsl_matrix_free(gsl_con_sub_F);
	}
	catch (...) {
		::Rf_error( "c++ exception (unknown reason)" );
	}
}

////
// main function solving the estimating equation when covariance possesses exponential structure
// cov(Z(x), Z(y)) = theta_2 exp(-theta_1 ||x-y||_2/theta_2)
// partion the restricted likelihood into a series of conditional likelihoods
// approximate the conditional likelihood by conditioning only on m observations
// x: x coordinate of the location, y: y coordinate of location, z: observations
// n: number of observations, theta: initial parameter
// theta: initial parameters
void arleGP_exp_lm(double *F, double *x, double *y, double *z, double *index, int *n, int *m, int *p,
	double *theta, int *maxiter, double *tol, double *f, double *grad)
{
	// alloc x,y,z and index
	gsl_vector_view gsl_x_view = gsl_vector_view_array(x, *n);
	gsl_vector_view gsl_y_view = gsl_vector_view_array(y, *n);
	gsl_vector_view gsl_z_view = gsl_vector_view_array(z, *n);
	gsl_vector_view gsl_theta = gsl_vector_view_array(theta, 2);
	gsl_matrix_view gsl_index_view = gsl_matrix_view_array(index, *n-*m, *m);
	gsl_matrix_view gsl_F_view = gsl_matrix_view_array(F, *n, *p);

	// allocate the parameter structure
	aspdatalm param;
	param.n = (*n);
	param.m = (*m);
	param.p = (*p);
	param.gsl_z = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_z, &gsl_z_view.vector);
	param.gsl_x = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_x, &gsl_x_view.vector);
	param.gsl_y = gsl_vector_alloc(*n);
	gsl_vector_memcpy(param.gsl_y, &gsl_y_view.vector);
	param.gsl_index = gsl_matrix_alloc(*n-*m, *m);
	gsl_matrix_memcpy(param.gsl_index, &gsl_index_view.matrix);
	param.gsl_F = gsl_matrix_alloc(*n, *p);
	gsl_matrix_memcpy(param.gsl_F, &gsl_F_view.matrix);

	// solve estimating equation
	const gsl_multimin_fdfminimizer_type *T;
	gsl_multimin_fdfminimizer *s;
	int status;
	int iter = 0;

	gsl_multimin_function_fdf my_func;
	
	my_func.n = 2;
	my_func.f = arle_exp_f_lm;
	my_func.df = arle_exp_df_lm;
	my_func.fdf = arle_exp_fdf_lm;
	my_func.params = &param;

	T = gsl_multimin_fdfminimizer_conjugate_fr;
	s = gsl_multimin_fdfminimizer_alloc (T, 2);
	
	gsl_multimin_fdfminimizer_set (s, &my_func, &gsl_theta.vector, 0.1, 0.1);

	do
	{
		iter++;
		status = gsl_multimin_fdfminimizer_iterate (s);
//		print_state (iter, s);
		if (status)
			break;
		
		status = gsl_multimin_test_gradient (s->gradient, *tol);
		theta[2*iter] = gsl_vector_get(s->x, 0);
		theta[2*iter+1] = gsl_vector_get(s->x, 1);
		f[iter-1] = gsl_multimin_fdfminimizer_minimum(s);
		grad[iter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
//		if (grad[iter-1]<*tol)
//			status = GSL_SUCCESS;
//		else
//			status = GSL_CONTINUE;
	}
	while (status == GSL_CONTINUE && iter < *maxiter);
		
	(*maxiter) = iter;
	f[*maxiter-1] = gsl_multimin_fdfminimizer_minimum(s);
	grad[*maxiter-1] = gsl_blas_dnrm2(gsl_multimin_fdfminimizer_gradient(s));
	theta[2*(*maxiter)] = gsl_vector_get(s->x, 0);
	theta[2*(*maxiter)+1] = gsl_vector_get(s->x, 1);

//	printf ("status = %s\n", gsl_strerror (status));
	gsl_multimin_fdfminimizer_free (s);
	
	// free allocation
	gsl_vector_free(param.gsl_z);
	gsl_vector_free(param.gsl_x);
	gsl_vector_free(param.gsl_y);
	gsl_matrix_free(param.gsl_index);
	gsl_matrix_free(param.gsl_F);
}


}