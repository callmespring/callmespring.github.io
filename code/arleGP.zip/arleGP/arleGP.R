## arleGP: Approximate likelihoods for large spatial data
## Two types of covariance functions are available
## Exponential type: cov(Z(x), Z(y))=theta_2 exp(-theta_1||x-y||_2/\theta_2)
## Power law variogram: var(Z(x)-Z(y))=2theta_2 ||x-y||_2^{theta_1}
## Number of conditioning variable: m

# calculate norm of vector
# norm <- function(x){
#	return (sqrt(sum(x^2)))
# }

# find indice and distance for nearest neighbour
NN <- function(Z, Y, X, m){
	n <- length(Z)
	# indice: indices matrix
	indice <- matrix(0, n-m, m)
	for (i in ((m+1):n)){
		dis <- sqrt((X[1:(i-1)]-X[i])^2+(Y[1:(i-1)]-Y[i])^2)
		indice[i-m, ] <- order(dis)[1:m]
	}
	
	return (indice = indice)
}

# order the observations
Order <- function(Y, X, method){
	if (method=="natural")
		myorder <- order(X+Y)
	else if (method=="center-out")
		myorder <- order((X-mean(X))^2+(Y-mean(Y))^2)
	else if (method=="outside-in") 
		myorder <- order((X-mean(X))^2+(Y-mean(Y))^2, decreasing=TRUE)
	else if (method=="random")
		myorder <- sample(1:length(Y))
	else{
		n <- length(Y)
		myorder <- sample(1:n, 1)
		Ax <- X[myorder]
		Ay <- Y[myorder]
		repeat{
			remain <- setdiff(1:n, as.numeric(myorder))
			row <- length(remain)
			if(row==1){
				myorder <- c(myorder, remain)
				break
			}
			xremain <- X[remain]
			yremain <- Y[remain]
			dis <- sapply(1:row,function(i) min((xremain[i]-Ax)^2+(yremain[i]-Ay)^2))
			myorder <- c(myorder, remain[which.max(dis)])
			Ax <- c(Ax, xremain[which.max(dis)])
			Ay <- c(Ay, yremain[which.max(dis)])
			if (length(myorder)==n)
				break
		}
		myorder <- as.numeric(myorder)		
	}

	return (myorder)
}

# # standard error of parameter estimates
# se_exp <- function(Y, X, m, theta, indice, r=3){
# 	n <- length(Y)
# 	indice_r <- matrix(0, n, r)
# 	for (i in 2:(n-1))
# 		indice_r[i,] <- sample(c(1:(i-1), (i+1):n), r)-1
# 	indice_r[n,] <- sample(1:(n-1), r)-1
# 	d2f <- rep(0, 3)
# 	d2g <- rep(0, 3)
# 	d2g <- .C("se_exp", as.double(d2f), as.double(d2g), as.double(X), as.double(Y), as.double(t(indice)), 
# 		as.integer(n), as.integer(m), as.double(theta), as.double(t(indice_r)), as.integer(r))
# 	d2f <- d2g[[1]]
# 	d2g <- d2g[[1]]
# 	
# 	J1 <- matrix(c(d2f[1], d2f[2], d2f[2], d2f[3]), 2, 2)
# 	J2 <- matrix(c(d2g[1], d2g[2], d2g[2], d2g[3]), 2, 2)
# 	return (diag(solve(t(J1)%*%solve(J2, J1))))
# }

# # derivatives of estimating equation
# DEEGP_exp <- function(Z, Y, X, m, theta, indice){
#   n <- length(Z)
#   d2f <- rep(0, 3)
#   if (m >= n){
#     for (i in 2:n){
#       d2f <- .C("exp_d2f_sub", as.double(d2f), as.double(Z[1:(i-1)]), as.double(Y[1:(i-1)]), 
#                 as.double(X[1:(i-1)]), as.double(Z[i]), as.double(Y[i]), as.double(X[i]), 
#                 as.integer(i-1), as.double(theta))
#       d2f <- d2f[[1]]
#     }
#   }
#   else{
#     for (i in 2:m){
#       d2f <- .C("exp_d2f_sub", as.double(d2f), as.double(Z[1:(i-1)]), as.double(Y[1:(i-1)]), 
#                 as.double(X[1:(i-1)]), as.double(Z[i]), as.double(Y[i]), as.double(X[i]), 
#                 as.integer(i-1), as.double(theta))
#       d2f <- d2f[[1]]
#     }
#     for (i in (m+1):n){
#       d2f <- .C("exp_d2f_sub", as.double(d2f), as.double(Z[indice[,i-m]]), as.double(Y[indice[,i-m]]), 
#                 as.double(X[indice[,i-m]]), as.double(Z[i]), as.double(Y[i]), as.double(X[i]), 
#                 as.integer(m), as.double(theta))
#       d2f <- d2f[[1]]
#     }
#   }
#   
#   J <- matrix(c(d2f[1], d2f[2], d2f[2], d2f[3]), 2, 2)
#   
#   return (J)
# }

# estimate parameter by maximizing approximated restricted likelihoods
# for exponential type covariance structure
# z: observations, y: y-coordinate, x: x-coordinate, m: NO. of conditioning variables
# theta: initial points for the algorithm
arleGP <- function(Z, Y, X, F=NULL, m, order=c("natural", "center-out", "outside-in", "max-min", "random"),
theta=theta0, maxiter=1000, tol=1e-7, mean=c("zero", "constant", "linear"), algo=c("newton", "gnewton", 
"hybridsj"))
{
  case <- 0
  if (algo=="newton")
    case <- 1
  else if (algo=="gnewton")
    case <- 2
  else
    case <- 3
    
	n <- length(Z)	
	
	# order the observations
	myorder <- Order(Y, X, order)
	Z <- Z[myorder]
	X <- X[myorder]
	Y <- Y[myorder]
  if (!is.null(F)){
    F <- as.matrix(F)
    F <- F[myorder, ]
  }
	
	# define f and gradient
	f <- rep(0, maxiter)
	grad <- rep(0, maxiter)
	theta <- c(theta, rep(0, 2*maxiter))
	
  if (mean=="zero"){
  
  	# find indices and distances using nearest neighbour
  	if (m<n){
  		indice <- t(NN(Z, Y, X, m))-1
  	
  	    # solve the problem using C
  		result <- .C("arleGP_exp", as.double(X), as.double(Y), as.double(Z), as.double(indice),
  		  as.integer(n), as.integer(m), as.double(theta), as.integer(maxiter), as.double(tol),
  		  as.double(f), as.double(grad), as.integer(case))
  		  
  		# function value and gradient
      if (maxiter>result[[8]])
  		  maxiter <- result[[8]]
  		f <- result[[10]]
  		f <- f[1:maxiter]
  		grad <- result[[11]]
  		grad <- grad[1:maxiter]
  		theta <- result[[7]]
  		theta <- theta[1:(2*maxiter+2)]
  		theta <- matrix(theta, 2, maxiter+1)
  	
  		return (list(theta=theta, f=f, grad=grad))
  	}
  	else{
  		result <- .C("rleGP_exp", as.double(X), as.double(Y), as.double(Z), as.integer(n), 
  			as.double(theta), as.integer(maxiter), as.double(tol), as.double(f), as.double(grad),
        as.integer(case))
  			
  		# function value and gradient
      if (maxiter>result[[6]])
  		  maxiter <- result[[6]]
  		f <- result[[8]]
  		f <- f[1:maxiter]
  		grad <- result[[9]]
  		grad <- grad[1:maxiter]
  		theta <- result[[5]]
  		theta <- theta[1:(2*maxiter+2)]
  		theta <- matrix(theta, 2, maxiter+1)	
      
  		return (list(theta=theta, f=f, grad=grad))
  	}
  }
  else if(mean=="constant"){
    
    # find indices and distances using nearest neighbour
    if (m<n){
      indice <- t(NN(Z, Y, X, m))-1
      
      # solve the problem using C
      result <- .C("arleGP_exp_cm", as.double(X), as.double(Y), as.double(Z), as.double(indice),
                   as.integer(n), as.integer(m), as.double(theta), as.integer(maxiter), as.double(tol),
                   as.double(f), as.double(grad), as.integer(case))
      
      # function value and gradient
      if (maxiter>result[[8]])
        maxiter <- result[[8]]
      f <- result[[10]]
      f <- f[1:maxiter]
      grad <- result[[11]]
      grad <- grad[1:maxiter]
      theta <- result[[7]]
      theta <- theta[1:(2*maxiter+2)]
      theta <- matrix(theta, 2, maxiter+1)
      
      return (list(theta=theta, f=f, grad=grad))
    }
    else{
      result <- .C("rleGP_exp_cm", as.double(X), as.double(Y), as.double(Z), as.integer(n), 
                   as.double(theta), as.integer(maxiter), as.double(tol), as.double(f), as.double(grad),
                   as.integer(case))
      
      # function value and gradient
      if (maxiter>result[[6]])
        maxiter <- result[[6]]
      f <- result[[8]]
      f <- f[1:maxiter]
      grad <- result[[9]]
      grad <- grad[1:maxiter]
      theta <- result[[5]]
      theta <- theta[1:(2*maxiter+2)]
      theta <- matrix(theta, 2, maxiter+1)	
      
      return (list(theta=theta, f=f, grad=grad))
    }
    
  }
	else{
	  p <- dim(F)[2]
    if (m<n){
      indice <- t(NN(Z, Y, X, m))-1
      
      # solve the problem using C
      result <- .C("arleGP_exp_lm", as.double(t(F)), as.double(X), as.double(Y), as.double(Z), 
                   as.double(indice), as.integer(n), as.integer(m), as.integer(p), as.double(theta), 
                   as.integer(maxiter), as.double(tol), as.double(f), as.double(grad), as.integer(case))
      
      # function value and gradient
      if (maxiter>result[[10]])
        maxiter <- result[[10]]
      f <- result[[12]]
      f <- f[1:maxiter]
      grad <- result[[13]]
      grad <- grad[1:maxiter]
      theta <- result[[9]]
      theta <- theta[1:(2*maxiter+2)]
      theta <- matrix(theta, 2, maxiter+1)
      
      return (list(theta=theta, f=f, grad=grad))
    }
    else{
  	  result <- .C("rleGP_exp_lm", as.double(t(F)), as.double(X), as.double(Y), as.double(Z), as.integer(n), 
  	               as.integer(p), as.double(theta), as.integer(maxiter), as.double(tol), as.double(f), 
  	               as.double(grad), as.integer(case))
  	  
  	  # function value and gradient
  	  if (maxiter>result[[8]])
  	    maxiter <- result[[8]]
  	  f <- result[[10]]
  	  f <- f[1:maxiter]
  	  grad <- result[[11]]
  	  grad <- grad[1:maxiter]
  	  theta <- result[[7]]
  	  theta <- theta[1:(2*maxiter+2)]
  	  theta <- matrix(theta, 2, maxiter+1)  
  	  
  	  return (list(theta=theta, f=f, grad=grad))
    }
	}
}